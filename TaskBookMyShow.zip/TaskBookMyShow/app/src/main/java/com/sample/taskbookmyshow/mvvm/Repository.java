package com.sample.taskbookmyshow.mvvm;


import io.reactivex.Observable;

/**
 * Created by AKASH on 29/12/19.
 */
public class Repository {
    private ApiCallInterface apiCallInterface;

    public Repository(ApiCallInterface apiCallInterface) {
        this.apiCallInterface = apiCallInterface;
    }

    Observable<String> getMovies(){
        return apiCallInterface.getMovies();
    }
}

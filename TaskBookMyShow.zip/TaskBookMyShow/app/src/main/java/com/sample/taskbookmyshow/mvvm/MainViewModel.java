package com.sample.taskbookmyshow.mvvm;


import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by AKASH on 29/12/19.
 */
public class MainViewModel extends ViewModel {
    private Repository repository;
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final MutableLiveData<ApiResponse> responseLiveData = new MutableLiveData<>();

    public MainViewModel(Repository repository){
        this.repository =repository;
    }

    public MutableLiveData<ApiResponse> getAPIResponse() {
        return responseLiveData;
    }

    // here api call
    public void getMovies(){
        disposables.add(repository.getMovies()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(d -> responseLiveData.setValue(ApiResponse.loading()))
                .subscribe(result -> responseLiveData.setValue(ApiResponse.success(result,"",200)),
                        error->responseLiveData.setValue(ApiResponse.error(error)))

        );
    }
}

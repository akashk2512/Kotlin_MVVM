package com.sample.taskbookmyshow;

/**
 * Created by AKASH on 29/12/19.
 */
public class AppConstant {
    public static final String GET_MOVIES_LIST = "course-apis/recyclerview/movies";

}

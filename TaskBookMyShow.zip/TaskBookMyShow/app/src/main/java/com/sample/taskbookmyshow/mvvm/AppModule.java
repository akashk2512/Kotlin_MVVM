package com.sample.taskbookmyshow.mvvm;

import android.content.Context;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

/**
 * Created by AKASH on 29/12/19.
 */
@Module
public class AppModule {
    private Context context;

    public AppModule(Context context) {
        this.context = context;
    }
    @Provides
    @Singleton
    Context provideContext(){
        return context;
    }
}

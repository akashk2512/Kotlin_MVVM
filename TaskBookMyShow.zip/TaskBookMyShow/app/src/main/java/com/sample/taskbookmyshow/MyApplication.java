package com.sample.taskbookmyshow;

import android.app.Application;
import android.content.Context;
import com.sample.taskbookmyshow.mvvm.AppComponent;
import com.sample.taskbookmyshow.mvvm.DaggerAppComponent;

/**
 * Created by AKASH on 29/12/19.
 */
public class MyApplication extends Application {
    private static Context mContext = null;
    private static MyApplication mInstance;
    AppComponent appComponent;

    @Override
    public void onCreate() {
        super.onCreate();

        this.mContext=this;
        appComponent = DaggerAppComponent.builder().build();
        mInstance = this;
    }

    public static synchronized MyApplication getInstance(){
        return mInstance;
    }

    public AppComponent getAppComponent(){return appComponent;}

}

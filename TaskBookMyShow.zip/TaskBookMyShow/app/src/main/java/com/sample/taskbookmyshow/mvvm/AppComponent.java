package com.sample.taskbookmyshow.mvvm;

import com.sample.taskbookmyshow.MainActivity;
import com.sample.taskbookmyshow.MovieListScreen;
import com.sample.taskbookmyshow.base.BaseServiceModule;
import dagger.Component;

import javax.inject.Singleton;

/**
 * Created by AKASH on 29/12/19.
 */
@Component(modules = {AppModule.class, BaseServiceModule.class})
@Singleton
public interface AppComponent {
    void doInjection(MovieListScreen movieListScreen);
}

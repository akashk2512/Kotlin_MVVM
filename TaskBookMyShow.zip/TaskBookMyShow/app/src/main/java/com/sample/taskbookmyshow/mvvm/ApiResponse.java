package com.sample.taskbookmyshow.mvvm;

import io.reactivex.annotations.NonNull;
import io.reactivex.annotations.Nullable;

import static com.sample.taskbookmyshow.mvvm.Status.*;

/**
 * Created by AKASH on 29/12/19.
 */
public class ApiResponse {
    public final Status status;
    @Nullable
    public final Object data;

    @Nullable
    public final Throwable error;

    public String message = null;
    public int errorCode;

    public ApiResponse(Status status, Object data, Throwable error, String message, int errorCode) {
        this.status = status;
        this.data = data;
        this.error = error;
        this.message = message;
        this.errorCode = errorCode;
    }

    public static ApiResponse loading() {
        return new ApiResponse(LOADING, null, null, null, 0);
    }

    public static ApiResponse success(@Nullable Object data, String message, int errorCode){
        if (errorCode==200){
            return new ApiResponse(SUCCESS,data,null,message,errorCode);
        }else {
            return new ApiResponse(FAILURE, data, null, message, errorCode);

        }
    }

    public static ApiResponse error(@NonNull Throwable error){
        return new ApiResponse(ERROR,null,error,null,0);

    }
}

package com.sample.taskbookmyshow.mvvm;

/**
 * Created by AKASH on 29/12/19.
 */
public enum Status {
    LOADING,
    SUCCESS,
    ERROR,
    FAILURE
}

package com.sample.taskbookmyshow;

/**
 * Created by AKASH on 29/12/19.
 */
public class AppConfig {
    public static final String BASE_URL_COMMON = "https://api.simplifiedcoding.in/";

}

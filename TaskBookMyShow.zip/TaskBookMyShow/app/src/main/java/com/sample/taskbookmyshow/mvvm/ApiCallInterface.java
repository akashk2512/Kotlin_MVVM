package com.sample.taskbookmyshow.mvvm;

import io.reactivex.Observable;
import retrofit2.http.GET;

/**
 * Created by AKASH on 29/12/19.
 */
public interface ApiCallInterface {
    @GET("")
    Observable<String> getMovies();
}

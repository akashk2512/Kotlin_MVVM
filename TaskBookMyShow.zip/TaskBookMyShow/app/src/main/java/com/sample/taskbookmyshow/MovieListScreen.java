package com.sample.taskbookmyshow;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.sample.taskbookmyshow.mvvm.MainViewModel;
import com.sample.taskbookmyshow.mvvm.ViewModelFactory;

import javax.inject.Inject;

public class MovieListScreen extends AppCompatActivity {

    @Inject
    ViewModelFactory viewModelFactory;
    MainViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list_screen);
        ((MyApplication) getApplication()).getAppComponent().doInjection(this);

    }
}
